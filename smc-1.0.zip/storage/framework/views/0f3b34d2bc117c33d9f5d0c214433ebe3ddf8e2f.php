<?php $__env->startSection('content'); ?>
    <!--Page BGS Image-->
    <div class="row">
        <div class="col-sm-12 bgs servicesBG half-height p-5">
            <div class="mx-auto p-5 mt-5 text-dark" style="width: fit-content;">
                <h1 style="font-size: 3.25rem;" class="font-weight-bold text-white">Services</h1>
            </div>
        </div>
    </div>
    <?php $__env->startComponent('services/services'); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>