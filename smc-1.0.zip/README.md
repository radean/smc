# smc
Saudi Maritime Company was established in early 1970’s by setting up an office in Dammam at Kingdom of Saudi Arabia by an enterprising Saudi Marine Captain, Ibrahim Barrak Al Omani, educated in United Kingdom and served as senior Ranking Officer on board reputed international shipping lines. Within a short span of time we have grown regionally covering Western and Eastern region of KSA. Our unique business model and enduring commitment propels us forward, we reach our goals. Saudi Maritime became part of absco.com (ABSA Group) in 1988 serving Principals and Agents worldwide.

# It is built on Laravel so Brace yourself

Its not an issue for a veteran developer. 