@extends('layout')


@section('content')

    <!--contact-->
    <div class="container">
        <h1>Contact US</h1>
    </div>

@endsection
